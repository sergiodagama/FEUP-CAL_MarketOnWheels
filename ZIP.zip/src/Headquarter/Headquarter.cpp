//
// Created by eunic on 24/04/2021.
//

#include "Headquarter.h"

Headquarter::Headquarter(unsigned int capital) {
    this->capital = capital;
}
