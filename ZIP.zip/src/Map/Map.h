//
// Created by eunic on 24/04/2021.
//

#ifndef SRC_MAP_H
#define SRC_MAP_H

#include "../Utils/Graph.h"
class Map {

};


#endif //SRC_MAP_H
